<?php
    if (isset($_GET)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>404 - page not found</title>
</head>
<body>
    <div class="container">
        <img src="../images/404error.png" alt="" class="img">
    </div>
</body>
</html>

<?php
    }
    else {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>404 - page not found</title>
</head>
<body>
    <div class="container">
        <img src="../images/404error.png" alt="" class="img">
    </div>
</body>
</html>

<?php
    } 
?>
