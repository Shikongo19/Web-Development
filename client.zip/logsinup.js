var sinupcollum = document.querySelector('.profile');
sinupcollum.style.display = "none";
