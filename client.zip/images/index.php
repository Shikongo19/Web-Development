<?php
    header("Location: ../error/");
?>