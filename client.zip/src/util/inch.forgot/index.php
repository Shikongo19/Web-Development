<?php 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <link rel="stylesheet" href="forgot.css">
    <title>Password Recovery</title>
</head>
<body>
    <div class="container">
        <div class="forms-container">
            <form action="" method="post" class="signin-form">
                <h2 class="title">forgot password !!!</h2>

                <div class="collum">
                    <p>Reset your password securely. Enter your email address to receive a password reset link. 
                        Follow the link in your email to set a new password and regain access to your account.
                    </p>
                    <div class="input-field">
                        <i class="fa fa-envelope"></i>
                        <input type="email" placeholder="example@domain.com" class="input">
                    </div>
                </div>
                
                <div class="float">
                    <input type="submit" value="continue" name="submit" class="submit">
                </div>
               
            </form>
            
        </div>
    </div>
    <div class="panels-container"></div>
    <div class="space"></div>
</body>
</html>