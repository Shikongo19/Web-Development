<?php 
session_start();
if (!isset($_SESSION['username'])) {?>

<?php 
    include_once("../../components/properties/db.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <link rel="stylesheet" href="./login.css">
    <script src="./toast.js" defer></script>
    <script src="./login.js" defer></script>
    <title>Login | Sign Up</title>
</head>
<body>

    <ul class="notifications"></ul>

    <div class="container">
        <div class="forms-container">
            <form action="" method="post" enctype="multipart/form-data" class="signin-form" autocomplete="off">
                <h2 class="title">sign in</h2>
                <div class="input-field">
                    <i class="fa fa-user"></i>
                    <input type="text" placeholder="username" name = "username" class="input">
                </div>
                <div class="input-field">
                    <i class="fa-solid fa-lock"></i>
                    <input type="password" placeholder="password" name = "password" class="input">
                </div>
                <input type="submit" value="Sign In" name="submit" class="submit">
                <a href="../inch.forgot" class="forgot">forgot password ?</a>
                <div class="media">
                    <i class="fa-brands fa-facebook"></i>
                    <i class="fa-brands fa-square-instagram"></i>
                    <i class="fa-brands fa-linkedin"></i>
                    <i class="fa-brands fa-square-whatsapp"></i>
                    <i class="fa-brands fa-square-youtube"></i>
                </div>
                <div class="register">Don't have account? <a href="../inch.register">Register</a></div>
            </form>
            
        </div>
    </div>
    <div class="panels-container"></div>
    <div class="space"></div>
    <?php
        include_once("../../components/footer/index.php");
    ?>
</body>
</html>

  <?php  }
    else {
        header("Location: ../../../");
    }
?>