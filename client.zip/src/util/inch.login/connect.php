<?php
    include_once("../../components/properties/db.php");
    
   
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    
    if(!empty($username) && !empty($password)){

        
        // hash the password
        $hashed_pass = hash("sha256", $password);

        //check if user name exist
        $sql = "SELECT Username FROM `user` WHERE Username = ? AND Password = ?";
        $stmt =$conn->prepare($sql);
        $stmt->bind_param("ss", $username, $hashed_pass);
        $stmt->execute();

        $result = $stmt->get_result();
        $data = $result->fetch_assoc();

        if ($stmt->affected_rows > 0) {

            session_start();
            $_SESSION['username'] = $username;
            
            echo "success";
        } else {
            echo " Invalid username or password !!!";
        } 
    }
    else {
        echo "All input fields are required !!!";
    }
    
?>