<?php 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <link rel="stylesheet" href="register.css">
    <script src="./register.js" defer></script>
    <title>Sign Up</title>
</head>
<body>
    <!--     %%%%%%%%%        toast         %%%%%%%%%    --->
    <ul class="notifications"></ul>

    <div class="container">
        <div class="forms-container">
            <form action="" method="post" enctype="multipart/form-data" class="signin-form">
                <h2 class="title">sign Up</h2>

                <h4 class="errorText"></h4>

                <div class="collum">
                    <div class="input-field">
                        <i class="fa fa-user"></i>
                        <input type="text" placeholder="first name" class="input" name="fname">
                    </div>
                    <div class="input-field">
                        <i class="fa fa-user"></i>
                        <input type="text" placeholder="last name" class="input" name="lname">
                    </div>
                </div>
                
                <div class="collum">
                    <div class="input-field">
                        <i class="fa-solid fa-user-plus"></i>
                        <input type="text" placeholder="username" class="input" name="username">
                    </div>
                    <div class="input-field">
                        <i class="fa-solid fa-envelope"></i>
                        <input type="text" placeholder="email" class="input" name="email">
                    </div>
                    <div class="input-field">
                        <i class="fa fa-lock"></i>
                        <input type="password" placeholder="password" class="input" name="password">
                    </div>
                </div>
                
                <div class="collum">
                    
                    <div class="input-field">
                        <i class="fa fa-lock"></i>
                        <input type="password"  class="input" name="confirm" placeholder="confirm password">
                    </div>
                    
                    <div class="input-field">
                        <i class="fa fa-file"></i>
                        <input type="file" class="input" name="image">
                    </div>
                </div>
                
                
                
                <div class="float">
                    <input type="submit" value="Sign Up" name="submit" class="submit">
                </div>
                
                <div class="media">
                    <i class="fa-brands fa-facebook"></i>
                    <i class="fa-brands fa-square-instagram"></i>
                    <i class="fa-brands fa-linkedin"></i>
                    <i class="fa-brands fa-square-whatsapp"></i>
                    <i class="fa-brands fa-square-youtube"></i>
                </div>
                <div class="register">Already have account? <a href="../inch.login">Sign In</a></div>
            </form>
            
        </div>
    </div>
    
    <div class="space"></div>
    <?php
        include_once("../../components/footer/index.php");
    ?>
    
</body>
</html>