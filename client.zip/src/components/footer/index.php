<div class="footer">
    <div class="footbox">
        <div class="content">
            <h2>quick links</h2>
            <a href="#home"><i class="fa-solid fa-house"></i> Home</a>
            <a href="#service"><i class="fa-brands fa-servicestack"></i> Our Service</a>
            <a href="#about"><i class="fa-solid fa-address-card"></i> About</a>
        </div>
        <div class="content">
            <h2>contact info</h2>
            <a href="tel:+264814272721"><i class="fa-solid fa-phone"></i> +264814272721</a>
            <a href="mailto:admin@omyetuitsolution.com"><i class="fa-solid fa-envelope"></i> admin@omyetuitsolution.com</a>
        </div>
        <div class="content">
            <h2>follow us</h2>
            <a href="https://instagram.com/omyetuits"><i class="fa-brands fa-square-instagram"></i> instagram</a>
            <a href="https://www.facebook.com/profile.php?id=100092732106024"><i class="fa-brands fa-square-facebook"></i> facebook</a>
        </div>
    </div>
    <p class="line"></p>
    <p class="copyright">copyright<i class="fa-regular fa-copyright"></i><span>2024</span> by <a href="">omyetu it solutions</a></p>
</div>