const form = document.querySelector(".signin-form");
submitbtn = form.querySelector(".submit");
errorText = form.querySelector(".errorText");

const notifications = document.querySelector(".notifications");
const toastmessage = document.querySelector(".error-message");

form.onsubmit = (e)=>{
    e.preventDefault();
}

submitbtn.onclick = () =>{
    let xhr = new XMLHttpRequest();
    xhr.open("POST", "./connect.php", true);
    xhr.onload = () =>{
        if(xhr.readyState === XMLHttpRequest.DONE){
            if(xhr.status === 200){
                let data = xhr.response;
                if (data === "success") {

                    let succs ="success";
                    let succmess = "You are successfuly registered !!!";

                    const toast = document.createElement("li");
                    toast.className = `toast ${succs}`;
                    toast.innerHTML = `

                        <div class="column">
                        <i class="fa-solid fa-circle-check"></i>
                        <span class="error-type">${succs}: </span>
                        <p class="error-message">${succmess}</p>
                        </div>

                    `;
                    notifications.appendChild(toast);
                    form.style.backgroundColor = "#00ff6a28";
                    setTimeout(() =>{
                        toast.classList.add("hide");
                        setTimeout(() =>{
                            form.style.backgroundColor = "#fff";
                            toast.style.display = "none";
                            notifications.removeChild(toast);
                        } ,300);
                    } ,5000);
                }
                else if (data === "noimage"){

                    let unsucc = "success:";
                    let succmess = "You have registered without a profile picture. !!!"

                    const toast = document.createElement("li");
                    toast.className = `toast ${unsucc}`;
                    toast.innerHTML = `

                        <div class="column">
                        <i class="fa-solid fa-alert"></i>
                        <span class="error-type">${unsucc}</span>
                        <p class="error-message">${succmess}</p>
                        </div>
                     
                    `;
                    notifications.appendChild(toast);
                    form.style.backgroundColor = "#f8fc033f";
                    setTimeout(() =>{
                        toast.classList.add("hide");
                        setTimeout(() =>{
                            form.style.backgroundColor = "#fff";
                            toast.style.display = "none";
                            notifications.removeChild(toast);
                        } ,300);
                    } ,5000);
                }
                else{
                    //errorText.textContent = data;

                    
                    let unsucc = "unsuccess";

                    const toast = document.createElement("li");
                    toast.className = `toast ${unsucc}`;
                    toast.innerHTML = `

                        <div class="column">
                        <i class="fa-solid fa-circle-check"></i>
                        <span class="error-type">Error: </span>
                        <p class="error-message">${data}</p>
                        </div>
                     
                    `;
                    notifications.appendChild(toast);
                    form.style.backgroundColor = "#fc3d033f";
                    setTimeout(() =>{
                        toast.classList.add("hide");
                        setTimeout(() =>{
                            form.style.backgroundColor = "#fff";
                            toast.style.display = "none";
                            notifications.removeChild(toast);
                        } ,300);
                    } ,5000);
                    
                }
            }
        }
    }

    let formData = new FormData(form);
    xhr.send(formData);
}