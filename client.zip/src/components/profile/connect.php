<?php
    include_once("../../components/properties/db.php");
    
    $fname = mysqli_real_escape_string($conn, $_POST['fname']);
    $lname = mysqli_real_escape_string($conn, $_POST['lname']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $image =  $_FILES['image'];
    
    
    if(!empty($fname) && !empty($lname) && !empty($username) && !empty($email) && !empty($password)){
        
        // check if the email is valid
        if(filter_var($email, FILTER_VALIDATE_EMAIL)){

            $sql = "SELECT Email FROM `user` WHERE Email = ?";
            $stmt =$conn->prepare($sql);
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $data = $result->fetch_assoc();

            //check if email is already exist
            if ($stmt->affected_rows > 0)  {
                echo " Invalid e-mail: $email - Please use a valid e-mail !!!";
            }
            else {

                //check if user name exist
                $sql = "SELECT Username FROM `user` WHERE Username = ?";
                $stmt =$conn->prepare($sql);
                $stmt->bind_param("s", $username);
                $stmt->execute();
                $result = $stmt->get_result();
                $data = $result->fetch_assoc();

                
                if ($stmt->affected_rows > 0)  {
                    echo " Invalid username: $username - please use a valid user name !!!";
                }
                else {
                    // lets check user file loaded
                    $error = $image['error'];
                    if ($error == 0) {

                        $time = time();

                        
                        $im_name = $image['name'];
                        $im_type = $image['type'];
                        $temp_name = $image['tmp_name'];

                        $explode = explode('.', $im_name);
                        $ext = end($explode);

                        $extentions = ['png', 'jpeg', 'jpg'];

                        // checking file type
                        if (in_array($ext, $extentions)) {

                            $new_im_name = $time.$im_name;
                            //if ( move_uploaded_file($temp_name, "../../../profile/".$new_im_name)){

                                $hashed_pass = hash("sha256", $password);
                                $status = "Active";

                                // insert data in database 
                                $sql = "INSERT INTO user(Username, Firstname, Lastname, Password, Email, Profile, Status) 
                                VALUES (?,?,?,?,?,?,?)";
                                
                                $stmt =$conn->prepare($sql);
                                $stmt->bind_param("sssssss", $username, $fname, $lname, $hashed_pass, $email, $new_im_name, $status);
                                $stmt->execute();

                                //$result = $stmt->get_result();
                                //$data = $result->fetch_assoc();

                                //check if record inserted

                                
                                $sql = "SELECT * FROM `user` WHERE Username = ?";
                                $stmt =$conn->prepare($sql);
                                $stmt->bind_param("s", $username);
                                $stmt->execute();
                                $result = $stmt->get_result();
                                $data = $result->fetch_assoc();

                                
                                if ($stmt->affected_rows > 0)  {

                                    if ( move_uploaded_file($temp_name, "../../../profile/".$new_im_name)){
                                        echo "success";
                                    }
                                    else {
                                        echo "Something went wrong !!!";
                                    }
                                }
                                else {
                                    echo "Something went wrong !!!";
                                }
                                
                            //}
                            //else {
                                //echo "Something went wrong !!!";
                            //}

                        }
                        else {
                            echo "Please upploade image with (png , jpeg, jpg) format !!!";
                        }
                        
                    }
                    elseif ($error == 1) {
                        echo "File too big !!!";
                    }
                    elseif ($error == 2) {
                        echo "File too big !!!";
                    }
                    elseif ($error == 3) {
                        echo "No image selected !!! $fname";
                    }
                    elseif ($error == 4) {

                        $hashed_pass = hash("sha256", $password);
                        $status = "Active";

                        // insert data in database 
                        $sql = "INSERT INTO user(Username, Firstname, Lastname, Password, Email, Status) 
                        VALUES (?,?,?,?,?,?)";
                                
                        $stmt =$conn->prepare($sql);
                        $stmt->bind_param("ssssss", $username, $fname, $lname, $hashed_pass, $email, $status);
                        $stmt->execute();

                        echo "noimage";
                    }
                    elseif ($error == 6) {
                        echo "Missing a temp folder !!!";
                    }
                    else{
                        echo "Failed to write file to disk !!!";
                    }
                }
            }
        }
        else {
            echo "$email - This is an invalid email !!!";
        }
    }
    else {
        echo "All input fields are required !!!";
    }
    
?>