<?php 
    session_start();
    if (isset($_SESSION)) {
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>

    <div class="container">
        <div class="form-container">
            <div class="background">
                <div class="prof">
                    <img src="../../../profile/victory.jpg" alt="">
                    <i class="fa-solid fa-user-pen"></i>
                </div>
            </div>
            <h1>Giideon Shikongo V</h1>
            <span>shikongov02@gmail.com</span>
        </div>
        <i class="fa-solid fa-pen-to-square"></i>
    </div>
    
    <?php 
        include_once("../footer/index.php");
    ?>
</body>
</html>

<?php
    }
    else {
        header("Location: ../../../error/");
    }
?>

    

