let btn = document.getElementsByClassName('.header');
const userinfo = document.querySelector('#userinfo');

var clicked = false;

btn.onlcick = () =>{
    console.log("clicked");
};