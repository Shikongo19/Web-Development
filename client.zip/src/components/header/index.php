<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./src/components/header/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"/>
    <title>Omyetu | Home</title>
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="./images/logo.png" alt="" width="100em" height="45em">
        </div>
        <ul class="leftnavbar">
            <ul class="links"> 
                <a class="active" href="#home">Home</a>
                <a href="#service">Our Service</a>
                <a href="#about">About</a>
                <a href="">our tutorials</a>
            </ul>
        </ul>
        
        <ul class="navbar">
            <ul id = "logsinup">
                <a href="">login / sign up</a>
            </ul>
            <ul class="shopbagbox">
                <i class="fa fa-shopping-bag border"></i>
            </ul>
            <ul class="media">
                <i class="fa-solid fa-bars border" id="menu"></i>
            </ul>
            <ul class="profile">
                <img src="./profile/victory.jpg" alt="">
                <i class="fa-solid fa-chevron-down"></i>
            </ul>
        </ul>
        <div class="userinfo" id="userinfo">
            <img src="./profile/victory.jpg" alt="">
            <h2 id="name">Giideon Shikongo</h2>
            <p>a software developer</p>
            <button id = "signout">sign out</button>
        </div>
        
    </div>