<?php
    header("Location: ../../error/");
?>