<?php
    $conn = mysqli_connect("localhost", "root", "", "omyetuitsolut171_db");
    if(!$conn){
        echo "Error: " .mysqli_connect_error();
    }
?>