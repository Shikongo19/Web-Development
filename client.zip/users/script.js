let menu = document.querySelector('#menu');
let navbar = document.querySelector('.leftnavbar');

menu.onclick = () =>{
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('activenavbar');
}


let btknn = document.querySelector('.header .navbar .profile .fa-chevron-down');
let userinfor = document.querySelector('.header .userinfo');

var controller =false;

btknn.onclick = () =>{
    btknn.classList.toggle('fa-times');
    if (!controller) {
        userinfor.style.height = "50vh";
        controller = true
    }
    else {
        userinfor.style.height = "0";
        controller = false;
    }
};

let signout = document.querySelector('#signout');

signout.onclick = () =>{
    window.location = "./logout.php";
};


let mission = document.querySelector('#missn');
let whoweare = document.querySelector('#missn2');


var isclicked = "off";
var isclicked1 = "off";
var ppress = false;


mission.onclick = () =>{
    let chev = document.querySelector('#missn .fa-chevron-down');
    chev.classList.toggle('fa-chevron-right');

    if (isclicked === "off") {
        const p = document.createElement("p");
                    
        p.innerHTML = `

                At <b>om' yetu it solutions</b>, our mission is to empower businesses and individuals through 
                cutting-edge web solutions. We believe in the transformative power of technology and 
                strive to make it accessible to everyone. Our goal is to create 
                websites and applications that not only meet but exceed your expectations

            `;
        mission.appendChild(p);
        isclicked = "on";
    }
    else{

        let newp = document.querySelector('#missn p')

        isclicked = "off";
        mission.removeChild(newp);
        
    }
    
};


whoweare.onclick = () =>{
    let chev = document.querySelector('#missn2 .fa-chevron-down');
    chev.classList.toggle('fa-chevron-right');

    if (isclicked1 === "off") {
        const p = document.createElement("p");
                    
        p.innerHTML = `

                    Established in 2020, <b>om' yetu it solutions</b> has emerged as a leader in the field of web development. 
                    With a team of highly skilled developers, designers, and strategists, we bring a wealth of experience and 
                    expertise to every project. Our diverse skill set allows us to 
                    tackle a wide range of projects, from simple websites to complex web applications.

            `;
            whoweare.appendChild(p);
        isclicked1 = "on";
    }
    else{

        let newp = document.querySelector('#missn2 p')

        isclicked1 = "off";
        whoweare.removeChild(newp);
        
    }
};


let apart = document.querySelector('#apart');
let apart1 = document.querySelector('#apart2');
let apart2 = document.querySelector('#apart3');
let apart3 = document.querySelector('#apart4');

var isclicked2 = "off";
var isclicked3 = "off";
var isclicked4 = "off";
var isclicked5 = "off";

apart.onclick = () =>{
    let chev = document.querySelector('.aboutbox .aboutcontent #apart .fa-chevron-down');
    chev.classList.toggle('fa-chevron-right');

    if (isclicked2 === "off") {
        const p = document.createElement("p");
                    
        p.innerHTML = `

                    We thrive on staying ahead of the curve. Our team is constantly exploring new technologies and 
                    methodologies to ensure your project is built with the latest and most effective tools.

            `;
            apart.appendChild(p);
        isclicked2 = "on";
    }
    else{

        let newp = document.querySelector('.aboutbox .aboutcontent #apart p')

        isclicked2 = "off";
        apart.removeChild(newp);
        
    }
};

apart1.onclick = () =>{
    let chev = document.querySelector('.aboutbox .aboutcontent #apart2 .fa-chevron-down');
    chev.classList.toggle('fa-chevron-right');

    if (isclicked3 === "off") {
        const p = document.createElement("p");
                    
        p.innerHTML = `
                    We believe in the power of collaboration. We work closely with our clients to understand their unique needs and goals, 
                    fostering a transparent and communicative partnership throughout the development process.
            `;
            apart1.appendChild(p);
        isclicked3 = "on";
    }
    else{

        let newp = document.querySelector('.aboutbox .aboutcontent #apart2 p')

        isclicked3 = "off";
        apart1.removeChild(newp);
        
    }
};

apart2.onclick = () =>{
    let chev = document.querySelector('.aboutbox .aboutcontent #apart3 .fa-chevron-down');
    chev.classList.toggle('fa-chevron-right');

    if (isclicked4 === "off") {
        const p = document.createElement("p");
                    
        p.innerHTML = `

                Your users are at the heart of our designs. We prioritize creating intuitive and 
                engaging user experiences to ensure that your audience not only stays but keeps coming back.

            `;
            apart2.appendChild(p);
        isclicked4 = "on";
    }
    else{

        let newp = document.querySelector('.aboutbox .aboutcontent #apart3 p')

        isclicked4 = "off";
        apart2.removeChild(newp);
        
    }
};

apart3.onclick = () =>{
    let chev = document.querySelector('.aboutbox .aboutcontent #apart4 .fa-chevron-down');
    chev.classList.toggle('fa-chevron-right');

    if (isclicked5 === "off") {
        const p = document.createElement("p");
                    
        p.innerHTML = `

                    Our commitment to quality is unwavering. Rigorous testing 
                    procedures and attention to detail are embedded in our development process to deliver flawless solutions.

            `;
            apart3.appendChild(p);
        isclicked5 = "on";
    }
    else{

        let newp = document.querySelector('.aboutbox .aboutcontent #apart4 p')

        isclicked5 = "off";
        apart3.removeChild(newp);
        
    }
};