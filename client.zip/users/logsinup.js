var sinupcollum = document.querySelector('#logsinup');
sinupcollum.style.display = "none";

var btn = document.querySelector('.header');
btn.onclik =() =>{
    console.log("clicked");
};